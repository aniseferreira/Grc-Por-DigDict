<?php

include 'entry_list.php';
